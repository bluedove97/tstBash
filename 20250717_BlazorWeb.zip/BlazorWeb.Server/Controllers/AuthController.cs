﻿using System.Security.Claims;
using BlazorWeb.Server.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BlazorWeb.Server.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IAuthService _authService;

        public AuthController(IAuthService authService)
        {
            _authService = authService;
        }

        [HttpPost("register")]
        public async Task<ActionResult<ServiceResponse<int>>> Register(UserRegister request)
        {
            var response = await _authService.Register(
                new User
                {
                    Email = request.Email
                },
                request.Password);

            if (!response.Success)
            {
                return BadRequest(response);
            }

            return Ok(response);
        }

        [HttpPost("login")]
        public async Task<ActionResult<ServiceResponse<string>>> Login(UserLogin request)
        {
            var response = await _authService.Login(request.Email, request.Password);
            if (!response.Success)
            {
                return BadRequest(response);
            }

            return Ok(response);
        }


        
        [Authorize]
        [HttpPost("change-password")]
        public async Task<ActionResult<ServiceResponse<bool>>> ChangePassword([FromBody] string newPassword)
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            var response = await _authService.ChangePassword(int.Parse(userId), newPassword);

            if (!response.Success)
            {
                return BadRequest(response);
            }

            return Ok(response);
        }

        public void TestAnnotation()
        {
            /*
         * 참고 : https://forum.dotnetdev.kr/t/asp-net-cores-what-why/6832/8
         * 
         * 
         * 
전통적으로 닷넷 웹앱은 인증/인가를 미들웨어가 처리합니다.
이때, 인증 스킴(AuthenticationScheme)이나 인증 정책(AuthorizationPolicy) 의 설정이 필요합니다.

인증 미들웨어는 바디에 담겨진 사용자 정보를 데이터 베이스 자료와 비교하여, 일치하면 사용자를 인증(HttpContext.User 에 ClaimsPrincipal 객체를 설정)하고, 이 정보를 인증 미들웨어(와 필요한 경우, 핸들러)가 사용하게 됩니다.

블레이저 서버는 Asp.Net Core 앱의 인증 방식에 의존하기 때문에, 보통의 경우, 인증과 관련한 흐름은 아래와 같습니다.

request => 인증 미들웨어 => 인가 미들웨어 => 핸들러(액션메서드) => 블레이저 영역 { AuthenticationStateProvider => 컴포넌트 }

보통의 경우, AuthenticationStateProvider의 역할은 인증 미들웨어가 설정한 HttpContext.User 정보를 바탕으로 인증 여부만 컴포넌트에게 전달하는 역할에 머무르는 게 일반적입니다.

인증 미들웨어와 협업을 하든, 직접 하든, AuthenticationStateProvider 가 제공한 인증 정보를 우리 코드에서 소비할 수도 있는데, 보여 주신 코드처럼 의존성 주입으로 직접 접근할 수도 있지만, 일반적으로는 캐스캐이딩으로 전달합니다.

<CascadingAuthenticationState>
...
...
</CascadingAuthenticationState>
캐이캐이딩으로 처리하면, 인증정보는 AuthorizeRouteView 에게 전달되고, 이는 다시 AuthorizeView 컴포넌트에게 전달됩니다. 이 객체는 Authorizing, Authorized, NotAuthorized 의 상태에 따라 UI의 노출 여부를 결정합니다.
즉, AuthorizeRouteView 는 인가 미들웨어와 비슷하고, AuthorizeView 는 상태가 세분화된 AuthorizeAttribute와 비슷하죠.

         */
        }
    }
}
