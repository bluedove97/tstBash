﻿using Dapper;

namespace BlazorWeb.Server.DBHelpers
{
    public class CategoryDBHelper
    {
        private readonly DataContext _dataContext;
        public CategoryDBHelper(DataContext dataContext)
        {
            _dataContext = dataContext;
        }


        public async Task<IEnumerable<Category>> GetCategories()
        {
            var sql = @" 
                select id, name, url
                from categories
                where 1=1
                order by id
                ";

            using var connection = _dataContext.CreateConnection();
            return await Task.FromResult(connection.Query<Category>(sql));
        }

    }
}
