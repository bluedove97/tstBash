﻿namespace BlazorWeb.Client.Services
{
    public interface IStorageLocalService
    {
        event Action OnChage;
        Task AddToCount();

        Task ResetCount();

    }
}
