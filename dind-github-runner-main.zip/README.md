# dind-github-runner


```
curl -fsSL -o docker.tgz https://download.docker.com/linux/static/stable/x86_64/docker-26.1.4.tgz
curl -fsSL -o containerd.tar.gz https://github.com/containerd/containerd/releases/download/v1.7.12/containerd-1.7.12-linux-amd64.tar.gz
curl -fsSL -o runc https://github.com/opencontainers/runc/releases/download/v1.1.12/runc.amd64
curl -fsSL -o cni-plugins.tgz https://github.com/containernetworking/plugins/releases/download/v1.3.0/cni-plugins-linux-amd64-v1.3.0.tgz
curl -fsSL -o actions-runner.tar.gz https://github.com/actions/runner/releases/download/v2.314.1/actions-runner-linux-x64-2.314.1.tar.gz
```
