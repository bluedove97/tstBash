const Layout = ({ children }) => {
  return (
    <></>
  )
}

export default Layout
