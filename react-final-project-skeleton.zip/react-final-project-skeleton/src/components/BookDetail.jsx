const BookDetail = () => {
  return (
    <></>
  )
}

export default BookDetail
