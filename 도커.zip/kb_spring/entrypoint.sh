#!/bin/sh

java -jar ${JAVA_OPT} /kb/JAR_NAME_REPLACE