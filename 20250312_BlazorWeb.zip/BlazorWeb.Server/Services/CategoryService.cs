﻿using System.Collections.Generic;
using BlazorWeb.Server.DBHelpers;
using BlazorWeb.Shared;

namespace BlazorWeb.Server.Services
{
    public class CategoryService : ICategoryService
    {
        private readonly CategoryDBHelper _categoryDbHelper;
        private readonly ILogger<CategoryService> _logger;

        public CategoryService(CategoryDBHelper categoryDbHelper, ILogger<CategoryService> logger)
        {
            _categoryDbHelper = categoryDbHelper;
            _logger = logger;
        }

        public async Task<ServiceResponse<IEnumerable<Category>>> GetCategories()
        {
            var response = new ServiceResponse<IEnumerable<Category>>();

            var result = await _categoryDbHelper.GetCategories();
            if (result != null)
            {
                response.Data = result;
            }

            return response;
        }

    }
}
