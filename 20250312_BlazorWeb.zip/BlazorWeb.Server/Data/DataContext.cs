﻿using System.Data;
using MySqlConnector;

namespace BlazorWeb.Server.Data
{
    public class DataContext
    {
        private readonly IConfiguration _configuration;
        private readonly string _connectionString;
        private MySqlConnection? connection = null;


        public DataContext(ILogger<DataContext> logger, IConfiguration configuration)
        {
            _configuration = configuration;
            _connectionString = _configuration.GetConnectionString("DefaultConnection");
        }

        public IDbConnection CreateConnection()
            => new MySqlConnection(_connectionString);

        private MySqlTransaction PrepareTransation(IsolationLevel isolationLevel)
        {
            //..
            //..
            //..
            return connection.BeginTransaction(isolationLevel);
        }

        private MySqlTransaction BeginTransation()
        {
            return PrepareTransation(System.Data.IsolationLevel.ReadCommitted);
        }

    }
}
