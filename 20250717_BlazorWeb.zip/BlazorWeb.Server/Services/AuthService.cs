﻿using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using BlazorWeb.Server.DBHelpers;
using BlazorWeb.Shared;
using Microsoft.Extensions.Configuration;
using System.Text;

namespace BlazorWeb.Server.Services
{
    public class AuthService : IAuthService
    {
        private readonly AuthDBHelper _authDBHelper;
        private readonly IConfiguration _configuration;
        private readonly ILogger<AuthService> _logger;
        

        public AuthService(AuthDBHelper authDBHelper, IConfiguration configuration, ILogger<AuthService> logger)
        {
            _authDBHelper = authDBHelper;
            _configuration = configuration;
            _logger = logger;
        }

        public async Task<ServiceResponse<int>> Register(User user, string password)
        {
            if (await UserExists(user.Email))
            {
                return new ServiceResponse<int>
                {
                    Success = false,
                    Message = "User already exists."
                };
            }
            else
            {
                CreatePasswordHash(password, out byte[] passwordHash, out byte[] passwordSalt);

                user.PasswordHash = passwordHash;
                user.PasswordSalt = passwordSalt;

                int result = _authDBHelper.CreateUser(user);
                return new ServiceResponse<int> 
                { 
                    Data = result, //user.Id,
                    Message = "Registration successful!" 
                };
            }
        }

        public async Task<ServiceResponse<string>> Login(string email, string password)
        {
            var response = new ServiceResponse<string>();
            var user = await _authDBHelper.GetUser(email.ToLower());            
            if (user == null)
            {
                response.Success = false;
                response.Message = "User not found.";
            }
            else if (!VerifyPasswordHash(password, user.PasswordHash, user.PasswordSalt))
            {
                response.Success = false;
                response.Message = "Wrong password.";
            }
            else
            {
                response.Data = CreateToken(user);
            }

            return response;
        }

        public async Task<bool> UserExists(string email)
        {
            int count = await _authDBHelper.UserExists(email);
            if (count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private void CreatePasswordHash(string password, out byte[] passwordHash, out byte[] passwordSalt)
        {
            using (var hmac = new HMACSHA512())
            {
                passwordSalt = hmac.Key;
                passwordHash = hmac.ComputeHash(System.Text.Encoding.UTF8.GetBytes(password));

                Console.WriteLine($"CreatePasswordHash.passwordHash={ByteToBase64String(passwordHash)}");
                Console.WriteLine($"CreatePasswordHash.PasswordSalt={ByteToBase64String(passwordSalt)}");
            }
        }

        private bool VerifyPasswordHash(string password, byte[] passwordHash, byte[] passwordSalt)
        {
            using (var hmac = new HMACSHA512(passwordSalt))
            {

                Console.WriteLine($"VerifyPasswordHash.PasswordSalt={ByteToBase64String(passwordSalt)}");
                Console.WriteLine($"VerifyPasswordHash.passwordHash={ByteToBase64String(passwordHash)}");

                var computedHash =
                    hmac.ComputeHash(System.Text.Encoding.UTF8.GetBytes(password));

                Console.WriteLine($"VerifyPasswordHash.computedHash={ByteToBase64String(computedHash)}");

                return computedHash.SequenceEqual(passwordHash);
            }
        }

        private string ByteToBase64String(byte[] byteVal)
        {
            //string str = Encoding.Default.GetString(byteVal);
            string str = Convert.ToBase64String(byteVal);
            return str;
        }

        private string CreateToken(User user)
        {
            List<Claim> claims = new List<Claim>
            {
                new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
                new Claim(ClaimTypes.Name, user.Email)
            };
            var key = new SymmetricSecurityKey(System.Text.Encoding.UTF8
                .GetBytes(_configuration.GetSection("AppSettings:Token").Value));

            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha512Signature);

            var token = new JwtSecurityToken(
                    claims: claims,
                    //expires: DateTime.Now.AddDays(1),
                    expires: DateTime.Now.AddMinutes(10),
                    signingCredentials: creds);

            var jwt = new JwtSecurityTokenHandler().WriteToken(token);

            return jwt;
        }

        public async Task<ServiceResponse<bool>> ChangePassword(int userId, string newPassword)
        {
            var user = await _authDBHelper.GetUser(userId);
            if (user == null)
            {
                return new ServiceResponse<bool>
                {
                    Data = false,
                    Success = false,
                    Message = "User not found."
                };
            }

            CreatePasswordHash(newPassword, out byte[] passwordHash, out byte[] passwordSalt);

            user.PasswordHash = passwordHash;
            user.PasswordSalt = passwordSalt;

            int result = await Task.FromResult(_authDBHelper.UpdateUserPassword(user));
            Console.WriteLine("ChangePassword="+result);
            if (result > 0)
            {
                return new ServiceResponse<bool> { Data = true, Success = true, Message = "Password has been changed." };
            }
            else
            {
                return new ServiceResponse<bool>
                {
                    Data = false,
                    Success = false,
                    Message = "Not changed."
                };
            }
            
        }
    }
}
