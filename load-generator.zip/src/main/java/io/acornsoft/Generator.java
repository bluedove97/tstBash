package io.acornsoft;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.xml.bind.DatatypeConverter;

public class Generator {
	
	private static String cpu = "";
	private static String mem = "";

	public static void main(String[] args) {

		cpu = System.getenv("V_CPU");
		mem = System.getenv("V_MEM");
		if(cpu == null || cpu.equals("")) cpu = "100";
		if(mem == null || mem.equals("")) mem = "200";
		
		System.out.println("* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *");
		System.out.println("설명:");
		System.out.println("  CPU와 메모리를 적정 수준으로 점유하는 dummy 프로그램입니다.");
		System.out.println("사용법:");
		System.out.println("  환경변수에 V_CPU, V_MEM값을 넣고 (default: V_CPU=100, V_MEM=200)");
		System.out.println("  java -jar load-generator.jar 구문으로 실행합니다.");
		System.out.println("* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *");
		System.out.println("V_CPU="+cpu);
		System.out.println("V_MEM="+mem);
		
		try {
			int numberOfThreads = Runtime.getRuntime().availableProcessors(); // 사용 가능한 프로세서 수
	        System.out.println("사용 가능한 프로세서 수: " + numberOfThreads);

	        for (int i = 0; i < numberOfThreads; i++) {
	            new BusyThread().start(); // 바쁜 스레드 생성 및 실행
	        }
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			System.out.println("프로세스를 꼭 종료해주세요.");
		}

	}
	
	
    private static class BusyThread extends Thread {
        @Override
        public void run() {
        	long tempTime = System.currentTimeMillis();
        	long cnt = 0;
        	
        	
            while (true) {
            	cnt++;
                // 계산을 수행하여 CPU 부하 생성
                try {
                	for(int i = 0; i < Integer.parseInt(cpu); i++) {
                		//double a = 314159 * 271828;
                		String uuid = UUID.randomUUID().toString();
                        String output = getMD5Digest(String.valueOf(uuid));
                    }
					Thread.sleep(1);
					
					if(cnt % 100000 == 0) {
						long endTime = (System.currentTimeMillis()-tempTime) / 1000;
						System.out.println(Thread.currentThread().getName()+"\trunning...\t"+endTime +" second");
					}
					
				} catch (InterruptedException e) {
					e.printStackTrace();
				} catch (Exception ee) {
					
				} finally {
                	FillMemory();
                	if(cnt > 100001) cnt = 0;
				}
            }
        }
    }
    
    private static void FillMemory() {
    	List<byte[]> memoryFiller = new ArrayList<>();

        try {
            while (memoryFiller.size() < Integer.parseInt(mem)) {
                memoryFiller.add(new byte[1048576]); // 1MB 배열 추가
                Thread.sleep(3);
                //System.out.println("memoryFiller.size()="+memoryFiller.size());
            }
        } catch (OutOfMemoryError e) {
            System.out.println("메모리 부족: " + memoryFiller.size() + " MB까지 채움");
            e.printStackTrace();
        } catch (Exception ee) {
        	ee.printStackTrace();
        } finally {
        	memoryFiller = new ArrayList<>();
        }
    }
    
    private static String getMD5Digest(String input) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("MD5");
        md.update(input.getBytes());
        byte[] digest = md.digest();
        String myHash = DatatypeConverter.printHexBinary(digest).toUpperCase();

        return myHash;
    }

}
