const Loading = () => (
  <></>
)

export default Loading