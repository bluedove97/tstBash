﻿using BlazorWeb.Shared;
using Dapper;

namespace BlazorWeb.Server.DBHelpers
{
    public class ProductDBHelper
    {
        private readonly DataContext _dataContext;
        public ProductDBHelper(DataContext dataContext)
        {
            _dataContext = dataContext;
        }


        public async Task<IEnumerable<Product>> GetProducts()
        {
            var sql = @" 
                select id, title, description, imageurl, price
                from products
                where 1=1
                order by id
                ";

            using var connection = _dataContext.CreateConnection();
            return await Task.FromResult(connection.Query<Product>(sql));
        }

        public async Task<IEnumerable<Product>> GetProductsByCategory(string categoryUrl)
        {
            var sql = @" 
                select p.id, title, description, imageurl, price
                from products p , categories c 
                where p.categoryid = c.id
                and c.url = @CategoryUrl
                order by p.id
                ";

            using var connection = _dataContext.CreateConnection();
            return await Task.FromResult(connection.Query<Product>(sql, new { CategoryUrl = categoryUrl }));
        }

        public async Task<Product> GetProduct(string productId)
        {
            var sql = @" 
                select id, title, description, imageurl, price
                from products
                where id = @ProductId
                ";

            using var connection = _dataContext.CreateConnection();
            return await Task.FromResult(connection.QuerySingle<Product>(sql, new { ProductId = productId }));
        }
    }
}
