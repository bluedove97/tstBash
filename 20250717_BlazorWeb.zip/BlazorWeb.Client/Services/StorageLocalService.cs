﻿
using Blazored.LocalStorage;

namespace BlazorWeb.Client.Services
{
    public class StorageLocalService : IStorageLocalService
    {
        ILocalStorageService _localStorage;

        public StorageLocalService(ILocalStorageService localStroage)
        {
            _localStorage = localStroage;
        }

        public event Action OnChage;

        public async Task AddToCount()
        {
            var count = await _localStorage.GetItemAsync<StorageLocal>("mycounter");
            if(count == null)
            {
                count = new StorageLocal 
                { 
                    Counter = 0 
                };
            }
            else
            {
                count.Counter++;
            }

            await _localStorage.SetItemAsync("mycounter", count);
        }

        public async Task ResetCount()
        {
            var count = new StorageLocal
            {
                Counter = 0
            };
            await _localStorage.SetItemAsync("mycounter", count);
        }
    }
}
