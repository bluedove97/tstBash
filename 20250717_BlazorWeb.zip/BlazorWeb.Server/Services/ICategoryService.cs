﻿namespace BlazorWeb.Server.Services
{
    public interface ICategoryService
    {
        public Task<ServiceResponse<IEnumerable<Category>>> GetCategories();

    }
}
