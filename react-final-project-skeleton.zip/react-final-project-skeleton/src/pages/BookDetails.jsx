const BookDetails = () => {
  return (
    <></>
  )
}

export default BookDetails
