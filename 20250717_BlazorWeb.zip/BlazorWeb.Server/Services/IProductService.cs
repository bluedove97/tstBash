﻿namespace BlazorWeb.Server.Services
{
    public interface IProductService
    {
        public Task<ServiceResponse<IEnumerable<Product>>> GetProducts();

        public Task<ServiceResponse<Product>> GetProduct(string productId);

        public Task<ServiceResponse<IEnumerable<Product>>> GetProductsByCategory(string categoryUrl);

    }
}
