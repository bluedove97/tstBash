﻿using System.Collections;
using System.Collections.Generic;
using BlazorWeb.Server.DBHelpers;
using BlazorWeb.Shared;

namespace BlazorWeb.Server.Services
{
    public class ProductService : IProductService
    {
        private readonly ProductDBHelper _productDbHelper;
        private readonly ILogger<ProductService> _logger;

        public ProductService(ProductDBHelper productDbHelper, ILogger<ProductService> logger)
        {
            _productDbHelper = productDbHelper;
            _logger = logger;
        }

        public async Task<ServiceResponse<IEnumerable<Product>>> GetProducts()
        {
            var response = new ServiceResponse<IEnumerable<Product>>();

            var result = await _productDbHelper.GetProducts();
            if (result != null)
            {
                response.Data = result;
            }

            return response;
        }

        public async Task<ServiceResponse<Product>> GetProduct(string productId)
        {
            var response = new ServiceResponse<Product>();

            var result = await _productDbHelper.GetProduct(productId);
            if (result != null)
            {
                response.Data = result;
            }

            return response;
        }

        public async Task<ServiceResponse<IEnumerable<Product>>> GetProductsByCategory(string categoryUrl)
        {
            var response = new ServiceResponse<IEnumerable<Product>>
            {
                Data = await _productDbHelper.GetProductsByCategory(categoryUrl)
            };

            return response;
        }
    }
}
