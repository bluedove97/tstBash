﻿using System.Data;
using Dapper;

namespace BlazorWeb.Server.DBHelpers
{
    public class AuthDBHelper
    {
        private readonly DataContext _dataContext;
        public AuthDBHelper(DataContext dataContext)
        {
            _dataContext = dataContext;
        }


        public async Task<User> GetUser(string email)
        {
            var sql = @" 
                select id,email,passwordhash, passwordsalt
                from users
                where email = @Email
                ";

            using var connection = _dataContext.CreateConnection();
            return await Task.FromResult(connection.QuerySingle<User>(sql, new { Email = email }));
        }

        public async Task<User> GetUser(int id)
        {
            var sql = @" 
                select id,email,passwordhash, passwordsalt
                from users
                where id = @Id
                ";

            using var connection = _dataContext.CreateConnection();
            return await Task.FromResult(connection.QuerySingle<User>(sql, new { Id = id }));
        }

        public async Task<int> UserExists(string email)
        {
            var sql = @" 
                select count(*) from dual
                where exists (select id from users where email = @Email);
                ";
            

            using var connection = _dataContext.CreateConnection();
            return await Task.FromResult(connection.QuerySingle<int>(sql, new { Email = email }));
        }

        public int CreateUser(User user)
        {
            Task<int> id;

            var param = new DynamicParameters();
            param.Add("@Email", user.Email);
            param.Add("@PasswordHash", user.PasswordHash, dbType: DbType.Binary);
            param.Add("@PasswordSalt", user.PasswordSalt, dbType: DbType.Binary);

            var sql = @"
               INSERT INTO users
                 (email, passwordhash, passwordsalt, datecreated)
               VALUES
                 (@Email, @PasswordHash, @PasswordSalt, NOW()) ; SELECT LAST_INSERT_ID();
            ";

            using var connection = _dataContext.CreateConnection();

            //return connection.ExecuteScalar<int>(sql, param);
            
            id = connection.QuerySingleAsync<int>(sql, param);

            return id.Result;

        }

        public int UpdateUserPassword(User user)
        {
            //Task<int> id;

            var param = new DynamicParameters();
            param.Add("@Id", user.Id);
            param.Add("@PasswordHash", user.PasswordHash, dbType: DbType.Binary);
            param.Add("@PasswordSalt", user.PasswordSalt, dbType: DbType.Binary);

            var sql = @"
               UPDATE users set 
                 passwordhash = @PasswordHash,
                 passwordsalt = @PasswordSalt
               WHERE id = @Id
            ";

            using var connection = _dataContext.CreateConnection();

            return connection.Execute(sql, param);

            //id = connection.QuerySingleAsync<int>(sql, param);

            //return id.Result;

        }

    }
}
