const Error = () => (
  <></>
)

export default Error